<!-- nav bar -->
<ul class="menu">
            <li class="menu-categories">
                <a href="index.php"class="categories-list list-menu">Acceuil</a>
            </li>


            <li class="menu-categories">
                <a class="categories-list">Utilisateurs</a>
            <ul style="padding-left: 10%; margin-top: 10px">
            <li class="list-menu">
                <a href="user_list.php">Liste des utilisateurs</a></li>
            </ul>
            </li>

            <li class="menu-categories">
                <a class="categories-list">Employes</a>
            <ul style="padding-left: 10%; margin-top: 10px">
            <li class="list-menu">
                <a href="employes_list.php">Liste des employes</a></li>
            <li class="list-menu">
                <a href="emp_add.php">Ajouter un employe</a></li>
            </ul>
            </li> 
            

            <li class="menu-categories">
                <a class="categories-list">Produits</a>
            <ul style="padding-left: 10%; margin-top: 10px;">
            <li class="list-menu">
                <a href="product_list_admin.php">Liste des Produits</a></li>
            <li class="list-menu">
                <a href="product_add.php">Ajouter Produits</a></li>
            </ul>
            </li>

            <li class="menu-categories">
                <a class="categories-list list-menu">Parametre</a>
            </li>
        </ul>
<!-- nav bar -->