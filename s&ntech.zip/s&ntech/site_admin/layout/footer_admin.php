<div class="footer">

    <a href="#" target="_blank"><p> Copyright © infotech 2022 </p></a>

</div>

</body>
</html>

<script src="public/js/script_admin.js"></script>
