<?php
include('layout/header_admin.php');
?>

<!-- content section -->
<div class="content">
    <?php include('layout/nav_admin.php'); ?>
    <div class="mainA">
        <h2>Profile</h2>
        <div class="card">
            <table>
                <tbody>
                    <tr>
                        <td>Username : soundous_and_nour</td>
                    </tr>
                    <tr>
                        <td>Email : soundousandnour@gmail.com</td>
                    </tr>
                    <tr>
                        <td>Role : Administrateur</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include('layout/footer_admin.php') ?>